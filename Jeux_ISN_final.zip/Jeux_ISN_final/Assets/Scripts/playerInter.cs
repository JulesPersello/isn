﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts;

public class playerInter : MonoBehaviour {

    public GameObject interObjectactu = null;
    public static Dictionary<GameObject, float> blocTimes = new Dictionary<GameObject, float>();
    private Money money;
    private NiveauDePioche niveaudepioche;
    private double[] multiplicateurs = { 1, 1.5, 2, 2.5, 3 };

    private void Start()
    {
        money = GameObject.FindGameObjectWithTag("MoneyTag").GetComponent<Money>();
        niveaudepioche = GameObject.FindGameObjectWithTag("PiocheTag").GetComponent<NiveauDePioche>();
    }

    void Update()
    {

        if (Input.GetButtonDown("Interaction") && interObjectactu)
        {
            if (!blocTimes.ContainsKey(interObjectactu))
            {
                Debug.Log(money);
                Debug.Log(niveaudepioche);
                blocTimes.Add(interObjectactu, Time.time + Random.Range(3,11));
                money.points += (int)(Random.Range(10, 21)*multiplicateurs[niveaudepioche.Lvl]);
                interObjectactu.SetActive(false);
            }
        }

        foreach (var blocTime in blocTimes)
        {

            var bloc = blocTime.Key;
            var time = blocTime.Value;


            if (time < Time.time)
            {
                bloc.SetActive(true);
                blocTimes.Remove(bloc);
            }
        }
    }


    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.CompareTag("interObject"))
        {
            Debug.Log(this.gameObject);
            interObjectactu = other.gameObject;
        }
    }


    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("interObject"))
        {
            if (other.gameObject == interObjectactu)
            {
                interObjectactu = null;
            }
        }
    }

}