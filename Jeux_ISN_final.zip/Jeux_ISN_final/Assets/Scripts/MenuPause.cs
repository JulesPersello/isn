﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuPause : MonoBehaviour
{
    public bool ShowGUI = false;
    public GameObject canvas;

    private void Start()
    {
        canvas = GameObject.Find("Canvas");
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            ShowGUI = !ShowGUI;
        }

        if (ShowGUI == true)
        {
            canvas.SetActive(true);
            Time.timeScale = 0;
        }

        else
        {
            canvas.SetActive(false);
            Time.timeScale = 1;
        }
    }

    public void Continue_theGame()
    {
        ShowGUI = false;
    }

    public void Quitter_theGame()
    {
        Application.Quit();
    }
}
       
