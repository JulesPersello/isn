﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts;

namespace Assets.Scripts
{
    public class NiveauDePioche : MonoBehaviour
    {

        private Money money;
        public int Lvl { get; set; }
        private int[] pts = { 50, 100, 150 };

        void Start()
        {
            money = GameObject.FindGameObjectWithTag("MoneyTag").GetComponent<Money>();
        }

        void Update()
        {
            if (Lvl < pts.Length && money.points >= pts[Lvl] && Input.GetButtonDown("ameliorationPioche"))
            {
                lock (money)
                {
                    money.points -= pts[Lvl];
                    Lvl++;
                    Debug.Log(Lvl);
                }
            }

        }
    }
}

