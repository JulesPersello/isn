﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Assets.Scripts;

public class Player : MonoBehaviour
{
    public Vector2 speed = new Vector2(50, 50);

    private Vector2 movement;
    private Rigidbody2D rigidbodyComponent;


    private Money money;
    private Timer timer;
    private float inputY;

    private void Start()
    {
        rigidbodyComponent = gameObject.GetComponent<Rigidbody2D>();



        money = GameObject.FindGameObjectWithTag("MoneyTag").GetComponent<Money>();
        timer = GameObject.FindGameObjectWithTag("TimerTag").GetComponent<Timer>();

    }

    private void Update()
    {
        float inputX = Input.GetAxis("Horizontal");

        movement = new Vector2(
           speed.x * inputX,
           speed.y * inputY);
    }

    void FixedUpdate()
    {
        if (rigidbodyComponent == null) rigidbodyComponent = GetComponent<Rigidbody2D>();

        rigidbodyComponent.velocity = movement;
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Nuggets"))
        {
            Destroy(collision.gameObject);
            money.points += 10;
        }
    }


}
