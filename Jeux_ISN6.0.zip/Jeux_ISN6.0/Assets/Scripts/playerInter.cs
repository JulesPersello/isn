﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerInter : MonoBehaviour {

    public GameObject interObjectactu = null;

    public static Dictionary<GameObject, float> blocTimes = new Dictionary<GameObject, float>();


    void Update()
    {
        if (Input.GetButtonDown("Interaction") && interObjectactu)
        {
            if (!blocTimes.ContainsKey(interObjectactu))
            {
                blocTimes.Add(interObjectactu, Time.time + 4);
                interObjectactu.SetActive(false);
            }
        }

        foreach (var blocTime in blocTimes)
        {

            var bloc = blocTime.Key;
            var time = blocTime.Value;


            if (time < Time.time)
            {
                bloc.SetActive(true);
                blocTimes.Remove(bloc);
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.CompareTag("interObject"))
        {
            Debug.Log(this.gameObject);
            interObjectactu = other.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("interObject"))
        {
            if (other.gameObject == interObjectactu)
            {
                interObjectactu = null;
            }
        }
    }

}