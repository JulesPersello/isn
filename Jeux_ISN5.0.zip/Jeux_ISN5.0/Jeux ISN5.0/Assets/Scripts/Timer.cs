﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts
{
    class Timer : MonoBehaviour
    {

        public Text tempsText;

        private void Update()
        {
            tempsText.text = ("Temps : " + (int)Time.time);
        }
    }
}
