﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Assets.Scripts;

public class Player : MonoBehaviour
{
    public float maxSpeed = 100;
    public float speed = 50f;
    public float jumpForce = 150f;

    public bool grounded;

    private Rigidbody2D rigidbodyComponent;
    private Animator anim;

    //private gameMaster gameMaster;
    private Money money;
    private Timer timer;

    private void Start()
    {
        rigidbodyComponent = gameObject.GetComponent<Rigidbody2D>();
        anim = gameObject.GetComponent<Animator>();

        //gameMaster = GameObject.FindGameObjectWithTag("GameMasterTag").GetComponent<gameMaster>();
        money = GameObject.FindGameObjectWithTag("MoneyTag").GetComponent<Money>();
        timer = GameObject.FindGameObjectWithTag("TimerTag").GetComponent<Timer>();

    }


    void Update()
    {
        anim.SetBool("Grounded",grounded);
        anim.SetFloat("Speed", Mathf.Abs(Input.GetAxis("Horizontal")));

        if (Input.GetAxis("Horizontal") < 0.1f)
        {
            transform.localScale = new Vector3(-1, 1, 1);
        }

        if (Input.GetAxis("Horizontal") > 0.1f)
        {
            transform.localScale = new Vector3(1, 1, 1);
        }

        if (Input.GetButtonDown("Jump"))
        {
            rigidbodyComponent.AddForce(Vector2.up * jumpForce);
            print("space key was pressed");
        }

    }

    void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal"); //Variable qui peut être négative ou positive, ce qui va donner le "coté" où le joueur va marcher

        //Mouvement du joueur
        rigidbodyComponent.AddForce((Vector2.right * speed) * h);

        //Limite la vitesse du joueur
        if (rigidbodyComponent.velocity.x > maxSpeed)
        {
            rigidbodyComponent.velocity = new Vector2(maxSpeed, rigidbodyComponent.velocity.y);
        }

        if (rigidbodyComponent.velocity.x < -maxSpeed)
        {
            rigidbodyComponent.velocity = new Vector2(-maxSpeed, rigidbodyComponent.velocity.y);
        }
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Nuggets"))
        {
            Destroy(collision.gameObject);
            money.points += 10;
        }
    }


}
