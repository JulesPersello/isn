﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts
{
    class Money : MonoBehaviour
    {

        public int points;
        public Text pointsText;

        private void Update()
        {
            pointsText.text = ("Argent: " + points);
        }

    }

}