﻿using UnityEngine;


public class Player : MonoBehaviour
{
    public float maxSpeed = 100;
    public float speed = 50f;
    public float jumpForce = 150f;

    public bool grounded;

    private Rigidbody2D rigidbodyComponent;
    private Animator anim; 


    private void Start()
    {
        rigidbodyComponent = gameObject.GetComponent<Rigidbody2D>();
        anim = gameObject.GetComponent<Animator>();
    }


    private void Update()
    {
   
    }

    void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal"); //Variable qui peut être négative ou positive, ce qui va donner le "coté" où le joueur va marcher

        //Mouvement du joueur
        rigidbodyComponent.AddForce((Vector2.right * speed) * h);

        //Limite la vitesse du joueur
        if (rigidbodyComponent.velocity.x > maxSpeed)
        {
            rigidbodyComponent.velocity = new Vector2(maxSpeed, rigidbodyComponent.velocity.y);
        }

        if (rigidbodyComponent.velocity.x < -maxSpeed)
        {
            rigidbodyComponent.velocity = new Vector2(-maxSpeed, rigidbodyComponent.velocity.y);
        }
    }



}
