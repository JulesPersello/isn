﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class objetInter : MonoBehaviour {

	void Update()
	{
		if (Input.GetButtonDown("Interaction") && interObjectactu)
		{
			Destroy(interObjectactu);
		}
	}

}