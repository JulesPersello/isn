﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerInter : MonoBehaviour {

    public GameObject interObjectactu = null;

    void Update()
    {
        if (Input.GetButtonDown("Interaction") && interObjectactu)
        {
            Destroy(interObjectactu);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.CompareTag("interObject"))
        {
            Debug.Log(other.name);
            interObjectactu = other.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("interObject"))
        {
            if (other.gameObject == interObjectactu)
            {
                interObjectactu = null;
            }
        }
    }

}
